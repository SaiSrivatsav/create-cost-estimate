sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("re.fin.createcostestimate.controller.App", {
      onInit() {
      }
  });
});